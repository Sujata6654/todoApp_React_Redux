export const ADD_TODO = 'ADD_TODO';
export const DELETE_TODO = 'DELETE_TODO';
export const UPDATE_CHECKBOX = 'UPDATE_CHECKBOX';

//for adding todo
export const addTodo=(payload)=>{
    return{
        type: ADD_TODO,
        payload
    }
}

//for deleting a todo
export const deleteTodo=(payload)=>{
    return{
        type: DELETE_TODO,
        payload
    }
}

//handle strike through checkbox
export const handleCheckbox=(payload)=>{
    return{
        type: UPDATE_CHECKBOX,
        payload
    }
}